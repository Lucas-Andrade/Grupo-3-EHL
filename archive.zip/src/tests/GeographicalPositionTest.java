package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import utils.Altitude;
import utils.GeographicalPosition;
import utils.Latitude;
import utils.Longitude;

public class GeographicalPositionTest {

	GeographicalPosition _geoPosObj;
	GeographicalPosition _geoPosVal;
	Latitude _lat;
	Longitude _lon;
	Altitude _alt;

	
	
	@Before
	public void newGepgraphicalPosition() 
	{
		_lat = new Latitude(60.00);
		_lon = new Longitude(160.00);
		_alt = new Altitude(1600.00);
		
		_geoPosObj = new GeographicalPosition(_lat, _lon, _alt);
		
		_geoPosVal = new GeographicalPosition(60.00, 160.00, 1600.00);
	}
	
	@Test
	public void shouldReturnLatitudeValue()
	{
		assertTrue(_geoPosObj.getLatitude() == _geoPosVal.getLatitude());
	}

	@Test
	public void shouldReturnLongitudeValue()
	{
		assertTrue(_geoPosObj.getLongitude() == _geoPosVal.getLongitude());
	}
	
	@Test
	public void shouldReturnAltitudeValue()
	{
		assertTrue(_geoPosObj.getAltitude() == _geoPosVal.getAltitude());
	}
	
	@Test
	public void shouldIncrementGeographicalPositionWithLatitudeLongitudeAndAltitudeObjects()
	{
		//Arrange
		Latitude lat = new Latitude(10.00);
		Longitude lon = new Longitude(10.00);
		Altitude alt = new Altitude(100.00);
		
		//Act
		_geoPosObj.incrementPosition(lat, lon, alt);
		
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
		assertTrue(170 == _geoPosObj.getLongitude());
		assertTrue(1700 == _geoPosObj.getAltitude());
	}
	
	@Test
	public void shouldIncrementGeographicalPositionWithLatitudeLongitudeAndAltitudeValues()
	{
		//Act
		_geoPosObj.incrementPosition(10, 10, 100);
		
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
		assertTrue(170 == _geoPosObj.getLongitude());
		assertTrue(1700 == _geoPosObj.getAltitude());
	}
	

	@Test
	public void shouldSetsALatitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.setLatitude(70);
	
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
	}
	
	@Test
	public void shouldSetsALatitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Latitude lat = new Latitude(70);
		
		//Act
		_geoPosObj.setLatitude(lat);
	
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
	}
	
	@Test
	public void shouldSetsALongitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.setLongitude(70);
	
		//Assert
		assertTrue(70 == _geoPosObj.getLongitude());
	}
	
	@Test
	public void shouldSetsALongitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Longitude lon = new Longitude(70);
		
		//Act
		_geoPosObj.setLongitude(lon);
	
		//Assert
		assertTrue(70 == _geoPosObj.getLongitude());
	}
	
	@Test
	public void shouldSetsAnAltitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.setAltitude(11000.00);
	
		//Assert
		assertTrue(11000.00 == _geoPosObj.getAltitude());
	}
	
	@Test
	public void shouldSetsAnAltitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Altitude alt = new Altitude(11000.00);
		
		//Act
		_geoPosObj.setAltitude(alt);
	
		//Assert
		assertTrue(11000.00 == _geoPosObj.getAltitude());
	}
	
	@Test
	public void shouldIncrementsALatitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.incrementLatitude(10);;
	
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
	}
	
	@Test
	public void shouldIncrementsALatitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Latitude lat = new Latitude(10);
		
		//Act
		_geoPosObj.incrementLatitude(lat);;
	
		//Assert
		assertTrue(70 == _geoPosObj.getLatitude());
	}
	
	@Test
	public void shouldIncrementsALongitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.incrementLongitude(10);
	
		//Assert
		assertTrue(170 == _geoPosObj.getLongitude());
	}
	
	@Test
	public void shouldIncrementsALongitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Longitude lon = new Longitude(10);
		
		//Act
		_geoPosObj.incrementLongitude(lon);
	
		//Assert
		assertTrue(170 == _geoPosObj.getLongitude());
	}
	
	@Test
	public void shouldIncrementsAnAltitudeInAGeographicalPositionWithAValue()
	{
		//Act
		_geoPosObj.incrementAltitude(1000.00);
	
		//Assert
		assertTrue(2600.00 == _geoPosObj.getAltitude());
	}
	
	@Test
	public void shouldIncrementsAnAltitudeInAGeographicalPositionWithAnObject()
	{
		//Arrange
		Altitude alt = new Altitude(1000.00);
		
		//Act
		_geoPosObj.incrementAltitude(alt);;
	
		//Assert
		assertTrue(2600.00 == _geoPosObj.getAltitude());
	}
}
